"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Image as ImageIcon } from "lucide-react";

interface Photo {
  id: number;
  url: string;
  caption: string;
  date?: string;
}

interface PhotoManagerProps {
  photos: Photo[];
  onPhotosChange: (photos: Photo[]) => void;
}

export default function PhotoManager({ photos, onPhotosChange }: PhotoManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newPhoto, setNewPhoto] = useState({
    url: "",
    caption: "",
    date: ""
  });

  const handleAddPhoto = () => {
    if (newPhoto.url && newPhoto.caption) {
      const photo: Photo = {
        id: Date.now(),
        url: newPhoto.url,
        caption: newPhoto.caption,
        date: newPhoto.date || undefined
      };
      
      onPhotosChange([...photos, photo]);
      setNewPhoto({ url: "", caption: "", date: "" });
      setIsDialogOpen(false);
    }
  };

  const handleRemovePhoto = (id: number) => {
    onPhotosChange(photos.filter(photo => photo.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Gerenciar Fotos</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Foto
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Adicionar Nova Foto</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="url">URL da Imagem</Label>
                <Input
                  id="url"
                  value={newPhoto.url}
                  onChange={(e) => setNewPhoto({ ...newPhoto, url: e.target.value })}
                  placeholder="https://exemplo.com/imagem.jpg"
                />
              </div>
              <div>
                <Label htmlFor="caption">Legenda</Label>
                <Textarea
                  id="caption"
                  value={newPhoto.caption}
                  onChange={(e) => setNewPhoto({ ...newPhoto, caption: e.target.value })}
                  placeholder="Uma breve descrição da foto..."
                />
              </div>
              <div>
                <Label htmlFor="date">Data (opcional)</Label>
                <Input
                  id="date"
                  value={newPhoto.date}
                  onChange={(e) => setNewPhoto({ ...newPhoto, date: e.target.value })}
                  placeholder="2024"
                />
              </div>
              <Button onClick={handleAddPhoto} className="w-full">
                Adicionar Foto
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {photos.map((photo) => (
          <Card key={photo.id} className="overflow-hidden">
            <div className="aspect-video relative">
              {photo.url ? (
                <img
                  src={photo.url}
                  alt={photo.caption}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-muted flex items-center justify-center">
                  <ImageIcon className="w-8 h-8 text-muted-foreground" />
                </div>
              )}
            </div>
            <CardContent className="p-4">
              <h4 className="font-medium text-sm mb-1">{photo.caption}</h4>
              {photo.date && (
                <p className="text-xs text-muted-foreground mb-2">{photo.date}</p>
              )}
              <Button
                variant="destructive"
                size="sm"
                onClick={() => handleRemovePhoto(photo.id)}
                className="w-full"
              >
                Remover
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}